/**
 * =============================================================================
 * VOICE COORDINATION SYSTEM
 * =============================================================================
 * File: public/js/voice-coordinator.js
 * Purpose: Mengelola koordinasi antara multiple voice features
 * Load: Sebelum semua voice scripts
 * =============================================================================
 */

(function() {
    'use strict';
    
    // Create global voice coordinator
    window.AudioStatistik = window.AudioStatistik || {};
    window.AudioStatistik.VoiceCoordinator = {
        
        // State management
        activeInstance: null,
        instances: new Map(),
        isSupported: 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window,
        
        // Register voice feature instance
        register: function(name, instance) {
            console.log(`🎤 Registering voice feature: ${name}`);
            this.instances.set(name, instance);
            
            // Auto-grant recognition untuk voice-search jika tidak ada aktif instance
            if (name === 'voice-search' && !this.activeInstance) {
                this.activeInstance = name;
                console.log(`✅ Auto-granted recognition access to ${name}`);
            }
            
            return true;
        },
        
        // Request speech recognition usage
        requestRecognition: function(name, callback) {
            if (!this.isSupported) {
                console.warn(`⚠️ Speech recognition not supported for ${name}`);
                return false;
            }
            
            // If same instance requesting, allow
            if (this.activeInstance === name) {
                console.log(`🎤 ${name} already has recognition access`);
                if (callback) setTimeout(callback, 10);
                return true;
            }
            
            // Stop current active instance
            if (this.activeInstance) {
                console.log(`🛑 Stopping ${this.activeInstance} to allow ${name}`);
                this.stopCurrent();
            }
            
            // Grant access to new instance
            this.activeInstance = name;
            console.log(`✅ Granting recognition access to ${name}`);
            
            if (callback) {
                setTimeout(callback, 100); // Small delay to ensure cleanup
            }
            
            return true;
        },
        
        // Release speech recognition
        releaseRecognition: function(name) {
            if (this.activeInstance === name) {
                console.log(`🔓 ${name} releasing recognition access`);
                this.activeInstance = null;
                return true;
            }
            return false;
        },
        
        // Stop current active instance
        stopCurrent: function() {
            if (this.activeInstance && this.instances.has(this.activeInstance)) {
                const instance = this.instances.get(this.activeInstance);
                if (instance && typeof instance.forceStop === 'function') {
                    try {
                        instance.forceStop();
                    } catch (error) {
                        console.warn(`⚠️ Error stopping ${this.activeInstance}:`, error);
                    }
                }
            }
        },
        
        // Check if a feature can use recognition
        canUseRecognition: function(name) {
            return !this.activeInstance || this.activeInstance === name;
        },
        
        // Get active instance name
        getActiveInstance: function() {
            return this.activeInstance;
        },
        
        // Priority system (higher number = higher priority)
        priorities: {
            'voice-search': 10,      // Highest priority
            'brs-navigation': 5,     // Medium priority
            'publications-navigation': 5,
            'search-navigation': 5,
            'welcome-message': 1     // Lowest priority
        },
        
        // Request with priority check
        requestWithPriority: function(name, callback) {
            const requestPriority = this.priorities[name] || 0;
            const activePriority = this.priorities[this.activeInstance] || 0;
            
            // Allow if higher or equal priority
            if (requestPriority >= activePriority) {
                return this.requestRecognition(name, callback);
            } else {
                console.log(`❌ ${name} denied access (priority ${requestPriority} < ${activePriority})`);
                return false;
            }
        },
        
        // Get registered instances
        getRegisteredInstances: function() {
            return Array.from(this.instances.keys());
        },
        
        // Force release all
        forceReleaseAll: function() {
            console.log('🔄 Force releasing all voice recognition');
            this.stopCurrent();
            this.activeInstance = null;
        },
        
        // Debug info
        getDebugInfo: function() {
            return {
                isSupported: this.isSupported,
                activeInstance: this.activeInstance,
                registeredInstances: this.getRegisteredInstances(),
                priorities: this.priorities
            };
        }
    };
    
    // Fire ready event
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(() => {
            document.dispatchEvent(new CustomEvent('voiceCoordinatorReady', {
                detail: { coordinator: window.AudioStatistik.VoiceCoordinator }
            }));
        }, 100);
    });
    
    console.log('🎛️ Voice Coordinator initialized');
    
})();