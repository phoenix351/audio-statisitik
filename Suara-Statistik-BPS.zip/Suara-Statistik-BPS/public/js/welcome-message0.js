(function() {
    'use strict';
    
    // Namespace management
    window.AudioStatistik = window.AudioStatistik || {};
    window.AudioStatistik.Voice = window.AudioStatistik.Voice || {};
    
    // Prevent double initialization
    if (window.AudioStatistik.Voice.Welcome) {
        console.log('🔄 Welcome Message already initialized');
        return;
    }

    class WelcomeMessage {
        constructor() {
            this.hasShownWelcome = false;
            this.isInitialized = false;
            this.utterance = null;
            this.sessionKey = 'audiostatistik_welcomed'; // Ubah key yang lebih spesifik
        }

        async init() {
            if (this.isInitialized) {
                console.log('🔄 Welcome Message already initialized');
                return;
            }

            // Only run on home page
            if (!this.isHomePage()) {
                console.log('ℹ️ Not home page, skipping welcome message');
                return;
            }

            console.log('🎉 Initializing Welcome Message');
            
            this.isInitialized = true;
            
            // Wait for voice coordinator to be ready
            this.waitForVoiceCoordinator(() => {
                // Wait a bit more for page to settle
                setTimeout(() => {
                    if (this.shouldShowWelcome()) {
                        this.showWelcomeMessage();
                    }
                }, 2000); // Increased delay
            });
            
            // Fire ready event
            document.dispatchEvent(new CustomEvent('welcomeMessageReady', {
                detail: { instance: this }
            }));
        }

        waitForVoiceCoordinator(callback) {
            if (window.AudioStatistik?.VoiceCoordinator) {
                callback();
            } else {
                setTimeout(() => this.waitForVoiceCoordinator(callback), 500);
            }
        }

        isHomePage() {
            const path = window.location.pathname;
            return path === '/' || path === '/home' || path.endsWith('/');
        }

        shouldShowWelcome() {
            // ✅ Fix: Reset session storage untuk testing
            // Uncomment baris di bawah untuk force reset welcome message
            // sessionStorage.removeItem(this.sessionKey);
            
            const welcomed = sessionStorage.getItem(this.sessionKey);
            console.log(`ℹ️ Welcome status check: ${welcomed ? 'Already welcomed' : 'Not welcomed yet'}`);
            
            if (welcomed) {
                console.log('ℹ️ User already welcomed in this session');
                return false;
            }
            
            return true;
        }

        async showWelcomeMessage() {
            try {
                console.log('🎤 Starting welcome message...');
                
                // ✅ Request recognition dari voice coordinator
                if (window.AudioStatistik?.VoiceCoordinator) {
                    const granted = window.AudioStatistik.VoiceCoordinator.requestRecognition('welcome-message');
                    if (!granted) {
                        console.log('⚠️ Could not get voice recognition access for welcome message');
                    }
                }
                
                const welcomeText = 'Selamat datang di Audio Statistik, portal audio untuk publikasi dan berita resmi statistik BPS Sulawesi Utara. ' +
                    'Gunakan tombol Ctrl untuk pencarian suara, atau katakan "Hai Audio Statistik". ' +
                    'Katakan "bantuan" untuk mendengar panduan lengkap perintah suara.';

                this.utterance = new SpeechSynthesisUtterance(welcomeText);
                this.utterance.lang = 'id-ID';
                this.utterance.rate = 0.8;
                this.utterance.volume = 0.9;
                
                this.utterance.onstart = () => {
                    console.log('🎤 Welcome message started');
                    this.hasShownWelcome = true;
                };
                
                this.utterance.onend = () => {
                    console.log('✅ Welcome message completed');
                    // Mark as welcomed
                    sessionStorage.setItem(this.sessionKey, 'true');
                    
                    // Release voice coordinator
                    if (window.AudioStatistik?.VoiceCoordinator) {
                        window.AudioStatistik.VoiceCoordinator.releaseRecognition('welcome-message');
                    }
                    
                    // Switch back to voice search after welcome
                    setTimeout(() => {
                        if (window.AudioStatistik?.VoiceCoordinator) {
                            window.AudioStatistik.VoiceCoordinator.requestWithPriority('voice-search');
                        }
                    }, 1000);
                };
                
                this.utterance.onerror = (event) => {
                    console.error('❌ Welcome message error:', event.error);
                    // Still mark as attempted to prevent loops
                    sessionStorage.setItem(this.sessionKey, 'true');
                };
                
                // ✅ Check if speech synthesis is available
                if ('speechSynthesis' in window) {
                    // Wait for voices to load
                    this.waitForVoices(() => {
                        window.speechSynthesis.speak(this.utterance);
                    });
                } else {
                    console.warn('⚠️ Speech synthesis not supported');
                    sessionStorage.setItem(this.sessionKey, 'true');
                }
                
            } catch (error) {
                console.error('❌ Error in showWelcomeMessage:', error);
                sessionStorage.setItem(this.sessionKey, 'true');
            }
        }

        waitForVoices(callback) {
            const voices = window.speechSynthesis.getVoices();
            if (voices.length > 0) {
                callback();
            } else {
                // Wait for voices to load
                window.speechSynthesis.addEventListener('voiceschanged', callback, { once: true });
                // Fallback timeout
                setTimeout(callback, 1000);
            }
        }

        // ✅ Public methods untuk debugging dan control
        forceShowWelcome() {
            console.log('🔄 Forcing welcome message...');
            sessionStorage.removeItem(this.sessionKey);
            this.hasShownWelcome = false;
            if (this.isHomePage()) {
                this.showWelcomeMessage();
            }
        }

        resetWelcome() {
            console.log('🔄 Resetting welcome message...');
            sessionStorage.removeItem(this.sessionKey);
            this.hasShownWelcome = false;
            if (this.utterance) {
                window.speechSynthesis.cancel();
            }
        }

        skipWelcome() {
            console.log('⏭️ Skipping welcome message...');
            sessionStorage.setItem(this.sessionKey, 'true');
            if (this.utterance) {
                window.speechSynthesis.cancel();
            }
        }

        cleanup() {
            if (this.utterance) {
                window.speechSynthesis.cancel();
            }
            // Release voice coordinator
            if (window.AudioStatistik?.VoiceCoordinator) {
                window.AudioStatistik.VoiceCoordinator.releaseRecognition('welcome-message');
            }
        }
    }

    // Initialize welcome message
    function initWelcomeMessage() {
        const welcomeMessage = new WelcomeMessage();
        window.AudioStatistik.Voice.Welcome = welcomeMessage;
        
        // Wait untuk voice coordinator siap
        function waitAndInit() {
            if (window.AudioStatistik?.VoiceCoordinator) {
                setTimeout(() => welcomeMessage.init(), 2000);
            } else {
                setTimeout(waitAndInit, 500);
            }
        }
        
        // Start waiting
        waitAndInit();
        
        // Global functions untuk manual control
        window.forceShowWelcome = () => welcomeMessage.forceShowWelcome();
        window.resetWelcome = () => welcomeMessage.resetWelcome();
        window.skipWelcome = () => welcomeMessage.skipWelcome();
    }

    // Initialize
    initWelcomeMessage();

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (window.AudioStatistik.Voice.Welcome) {
            window.AudioStatistik.Voice.Welcome.cleanup();
        }
    });

    console.log('✅ Welcome Message script loaded and enhanced');

})();