(function() {
    // Global audio management - Enhanced version with fixes
    let currentGlobalAudio = null;
    let currentDocument = null;
    let currentFormat = 'mp3';
    let isPlaying = false;
    let recognition = null;
    let textSoundEnabled = true;
    let audioPlayerManager;

    // Initialize on page load
    document.addEventListener('DOMContentLoaded', function() {
        initializePage();
        initializeStickyNavbar();
    });

    function initializePage() {
        // Mobile menu toggle
        document.getElementById('mobile-menu-button').addEventListener('click', function() {
            const menu = document.getElementById('mobile-menu');
            const isHidden = menu.classList.contains('hidden');
            menu.classList.toggle('hidden');
            this.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
        });

        // Initialize universal text hover sounds
        initializeUniversalTextHoverSounds();
        
        // Initialize enhanced audio player
        // initializeEnhancedAudioPlayer();

        // ✅ Initialize voice search di sini
        initializeVoiceSearch();

        // Welcome message only (no voice recognition)
        // if (!isAuthPage()) {
        //     initializeWelcomeMessage();
        // }
    }

    function isAuthPage() {
        const path = window.location.pathname;
        return path.includes('login') || path.includes('register');
    }

    function initializeWelcomeMessage() {
        // Welcome audio message (only on home page and first visit)
        if (window.location.pathname === '/' && !sessionStorage.getItem('welcomed')) {
            setTimeout(() => {
                // Check if unified voice system is not currently active
                if (!window.unifiedVoiceSystem || !window.unifiedVoiceSystem.isSpeaking) {
                    const welcomeMessage = new SpeechSynthesisUtterance(
                        'Selamat datang di Audio Statistik, portal audio untuk publikasi dan berita resmi statistik BPS Sulawesi Utara. ' +
                        'Gunakan tombol Ctrl untuk pencarian suara, atau katakan "Hai Audio Statistik". ' +
                        'Katakan "bantuan" untuk mendengar panduan lengkap perintah suara.'
                    );
                    welcomeMessage.lang = 'id-ID';
                    welcomeMessage.rate = 0.9;
                    
                    welcomeMessage.onend = () => {
                        console.log('Welcome message completed');
                    };
                    
                    window.speechSynthesis.speak(welcomeMessage);
                    sessionStorage.setItem('welcomed', 'true');
                }
            }, 5000); // Delay longer to avoid conflict
        }
    }

    function initializeUniversalTextHoverSounds() {
        // Add hover sound to ALL text elements
        const textElements = document.querySelectorAll('.text-sound, p, h1, h2, h3, h4, h5, h6, span, div, label, button, a, td, th, li');
        
        textElements.forEach(element => {
            // Skip if element is empty or only contains icons
            if (!element.textContent || element.textContent.trim() === '' || element.innerHTML.includes('fas fa-') && element.textContent.trim().length < 3) {
                return;
            }

            element.addEventListener('mouseenter', function() {
                if (textSoundEnabled) {
                    playTextHoverSound();
                    // Optional: speak short text content for accessibility
                    speakTextContent(this);
                }
            });
        });

        // Add keyboard shortcut to toggle text sounds (Ctrl + T)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 't') {
                e.preventDefault();
                textSoundEnabled = !textSoundEnabled;
                announceToScreenReader(textSoundEnabled ? 'Suara hover teks diaktifkan' : 'Suara hover teks dinonaktifkan');
            }
        });
    }

    function playTextHoverSound() {
        try {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            // Subtle, pleasant sound for text hover
            oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.01);
            gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.08);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.08);
        } catch (e) {
            // Silently fail if Web Audio API is not supported
        }
    }

    function speakTextContent(element) {
        // Only speak very short text for labels/buttons, avoid overwhelming the user
        const text = element.textContent.trim();
        
        // Skip if text is too long, empty, or only contains special characters
        if (text.length > 500 || text.length < 2 || /^[^a-zA-Z0-9\s]+$/.test(text)) {
            return;
        }

        // Skip if text is just numbers or very common words
        if (/^\d+$/.test(text) || ['menu', 'home', 'back', 'next', 'prev'].includes(text.toLowerCase())) {
            return;
        }

        // Skip if speech synthesis is not available or already speaking
        if (!window.speechSynthesis || window.speechSynthesis.speaking) {
            return;
        }

        // Only speak labels, buttons, and links
        const tagName = element.tagName.toLowerCase();
        if (!['button', 'a', 'label', 'span'].includes(tagName)) {
            return;
        }

        // Create and speak utterance with very low volume and fast rate
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'id-ID';
        utterance.rate = 1.5;
        utterance.volume = 0.3;
        utterance.pitch = 1.1;
        
        // Delay to avoid overlapping with hover sound
        setTimeout(() => {
            if (!window.speechSynthesis.speaking) {
                window.speechSynthesis.speak(utterance);
            }
        }, 100);
    }

    // Enhanced audio player initialization
    function initializeEnhancedAudioPlayer() {
        const mainAudio = document.getElementById('main-audio-element');
        const playPauseBtn = document.getElementById('play-pause-main-btn');
        const progressContainer = document.getElementById('progress-container-main');
        const progressBar = document.getElementById('progress-bar-main');
        const currentTimeEl = document.getElementById('current-time-main');
        const totalTimeEl = document.getElementById('total-time-main');
        const formatMp3Btn = document.getElementById('format-mp3');
        const formatFlacBtn = document.getElementById('format-flac');
        const downloadBtn = document.getElementById('download-btn-main');
        const closeBtn = document.getElementById('close-player-btn');
        const popupBtn = document.getElementById('popup-btn');
        const speedBtn = document.getElementById('speed-btn');
        const closeSidebarBtn = document.getElementById('close-sidebar-btn');
        
        if (!mainAudio) {
            console.warn('⚠️ Main audio element not found, skipping audio player initialization');
            return;
        }

        let currentSpeed = 1.0;
        const speeds = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];
        let speedIndex = 2;

        // CRITICAL FIX: Enhanced playDocumentAudio function with renamed parameter
        window.playDocumentAudio = function(docData) {
            console.log('🎵 Starting enhanced playDocumentAudio for:', docData.title);
            
            // Stop all existing audio
            stopAllAudio();
            
            // Update current document
            currentDocument = docData;
            currentGlobalAudio = mainAudio;
            
            // Show bottom player
            const bottomPlayer = document.getElementById('bottom-audio-player');
            if (bottomPlayer) {
                bottomPlayer.classList.remove('hidden');
                console.log('✅ Bottom player shown');
            } else {
                console.warn('⚠️ Bottom audio player element not found');
            }
            
            // Update player UI
            updatePlayerUI(docData);
            
            // Load and play audio
            loadAndPlayAudio(docData);
            
            // Announce to screen reader
            announceToScreenReader(`Memutar dokumen: ${docData.title}`);
        };

        function stopAllAudio() {
            // Stop global audio
            if (currentGlobalAudio && !currentGlobalAudio.paused) {
                currentGlobalAudio.pause();
                currentGlobalAudio.currentTime = 0;
            }

            // Stop all inline audio players
            document.querySelectorAll('.audio-element').forEach(audio => {
                if (!audio.paused) {
                    audio.pause();
                    audio.currentTime = 0;
                    
                    // Reset play button icons for inline players
                    const player = audio.closest('.audio-player');
                    if (player) {
                        const playBtn = player.querySelector('.play-pause-btn i');
                        if (playBtn) {
                            playBtn.classList.remove('fa-pause');
                            playBtn.classList.add('fa-play');
                        }
                    }
                }
            });

            // Stop any other HTML5 audio elements
            document.querySelectorAll('audio').forEach(audio => {
                if (audio !== currentGlobalAudio && !audio.paused) {
                    audio.pause();
                    audio.currentTime = 0;
                }
            });
            
            console.log('🛑 All audio stopped');
        }

        function updatePlayerUI(docData) {
            // Update bottom player info
            const elements = {
                'current-doc-title': docData.title,
                'current-doc-indicator': docData.indicator?.name || 'Unknown',
                'total-time-main': docData.audio_duration_formatted || '00:00'
            };

            Object.entries(elements).forEach(([id, text]) => {
                const element = document.getElementById(id);
                if (element) {
                    element.textContent = text;
                } else {
                    console.warn(`⚠️ Element with id '${id}' not found`);
                }
            });

            // Update cover image
            const coverImg = document.getElementById('current-doc-cover');
            if (coverImg) {
                coverImg.src = `/documents/${docData.id}/cover`;
                coverImg.alt = `Cover ${docData.title}`;
            }

            // Update sidebar info
            updateSidebarInfo(docData);
            
            console.log('✅ Player UI updated');
        }

        function updateSidebarInfo(docData) {
            const sidebarElements = {
                'sidebar-doc-title': docData.title,
                'sidebar-doc-indicator': docData.indicator?.name || 'Unknown',
                'sidebar-doc-description': docData.description || 'Tidak ada deskripsi tersedia.',
                'sidebar-doc-date': 'Tahun ' + docData.year,
                'sidebar-audio-duration': docData.audio_duration_formatted || '-',
                'sidebar-audio-format': currentFormat.toUpperCase()
            };

            Object.entries(sidebarElements).forEach(([id, text]) => {
                const element = document.getElementById(id);
                if (element) element.textContent = text;
            });

            const sidebarCover = document.getElementById('sidebar-doc-cover');
            if (sidebarCover) {
                sidebarCover.src = `/documents/${docData.id}/cover`;
                sidebarCover.alt = `Cover ${docData.title}`;
            }
        }

        function loadAndPlayAudio(docData) {
            if (!mainAudio) {
                console.error('❌ Main audio element not found');
                return;
            }
            
            // Prepare audio URL
            const audioUrl = `/documents/${docData.id}/audio/${currentFormat}/stream`;
            console.log('🔗 Loading audio from:', audioUrl);
            
            // Clear existing sources and set new one
            mainAudio.innerHTML = '';
            const source = document.createElement('source');
            source.src = audioUrl;
            source.type = currentFormat === 'mp3' ? 'audio/mpeg' : 'audio/flac';
            mainAudio.appendChild(source);
            
            // Load and play
            mainAudio.load();
            
            mainAudio.addEventListener('loadedmetadata', function() {
                console.log('📊 Audio metadata loaded, duration:', mainAudio.duration);
                updateTotalTime(mainAudio.duration);
            }, { once: true });

            mainAudio.addEventListener('canplay', function() {
                console.log('▶️ Audio can play, starting playback...');
                
                mainAudio.play()
                    .then(() => {
                        console.log('✅ Audio started playing');
                        isPlaying = true;
                        updatePlayButtonState(true);
                    })
                    .catch(error => {
                        console.error('❌ Failed to play audio:', error);
                        announceToScreenReader('Gagal memutar audio. Silakan coba lagi.');
                    });
            }, { once: true });

            mainAudio.addEventListener('error', function(e) {
                console.error('❌ Audio error:', e);
                announceToScreenReader('Terjadi kesalahan saat memuat audio.');
            });
        }

        function updateTotalTime(duration) {
            if (duration && !isNaN(duration) && totalTimeEl) {
                totalTimeEl.textContent = formatTime(duration);
            }
        }

        function updatePlayButtonState(playing) {
            const icon = playPauseBtn?.querySelector('i');
            
            if (icon) {
                if (playing) {
                    icon.classList.remove('fa-play');
                    icon.classList.add('fa-pause');
                    playPauseBtn.setAttribute('title', 'Jeda');
                    playPauseBtn.setAttribute('aria-label', 'Jeda audio');
                } else {
                    icon.classList.remove('fa-pause');
                    icon.classList.add('fa-play');
                    playPauseBtn.setAttribute('title', 'Putar');
                    playPauseBtn.setAttribute('aria-label', 'Putar audio');
                }
            }
        }

        // Play/Pause functionality
        if (playPauseBtn) {
            playPauseBtn.addEventListener('click', function() {
                if (!currentGlobalAudio || !currentGlobalAudio.src) {
                    console.log('⚠️ No audio loaded');
                    return;
                }
                
                if (currentGlobalAudio.paused) {
                    // Stop all other audio first
                    stopAllAudio();
                    currentGlobalAudio = mainAudio; // Reset reference
                    
                    currentGlobalAudio.play()
                        .then(() => {
                            isPlaying = true;
                            updatePlayButtonState(true);
                            console.log('▶️ Resumed playing');
                        })
                        .catch(error => {
                            console.error('❌ Play failed:', error);
                            announceToScreenReader('Gagal memutar audio');
                        });
                } else {
                    currentGlobalAudio.pause();
                    isPlaying = false;
                    updatePlayButtonState(false);
                    console.log('⏸️ Paused');
                }
            });
        }

        // Progress tracking
        if (mainAudio && progressBar && currentTimeEl) {
            mainAudio.addEventListener('timeupdate', function() {
                if (mainAudio.duration && !isNaN(mainAudio.duration)) {
                    const progress = (mainAudio.currentTime / mainAudio.duration) * 100;
                    progressBar.style.width = progress + '%';
                    currentTimeEl.textContent = formatTime(mainAudio.currentTime);
                }
            });
        }

        // Seek functionality
        if (progressContainer) {
            progressContainer.addEventListener('click', function(e) {
                if (currentGlobalAudio && currentGlobalAudio.duration && !isNaN(currentGlobalAudio.duration)) {
                    const rect = this.getBoundingClientRect();
                    const clickX = e.clientX - rect.left;
                    const percentage = clickX / rect.width;
                    currentGlobalAudio.currentTime = percentage * currentGlobalAudio.duration;
                    console.log('⏩ Seek to:', formatTime(currentGlobalAudio.currentTime));
                }
            });
        }

        // Format switching
        if (formatMp3Btn) {
            formatMp3Btn.addEventListener('click', function() {
                switchFormat('mp3');
            });
        }

        if (formatFlacBtn) {
            formatFlacBtn.addEventListener('click', function() {
                switchFormat('flac');
            });
        }

        // Speed control
        if (speedBtn) {
            speedBtn.addEventListener('click', function() {
                speedIndex = (speedIndex + 1) % speeds.length;
                currentSpeed = speeds[speedIndex];
                if (currentGlobalAudio) {
                    currentGlobalAudio.playbackRate = currentSpeed;
                }
                const speedDisplay = this.querySelector('span');
                if (speedDisplay) {
                    speedDisplay.textContent = currentSpeed + 'x';
                }
                announceToScreenReader(`Kecepatan diubah ke ${currentSpeed}x`);
            });
        }

        // Download functionality
        if (downloadBtn) {
            downloadBtn.addEventListener('click', function() {
                if (currentDocument) {
                    const downloadUrl = `/documents/${currentDocument.id}/audio/${currentFormat}/download`;
                    const link = document.createElement('a');
                    link.href = downloadUrl;
                    link.download = '';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    announceToScreenReader(`Mengunduh audio dalam format ${currentFormat.toUpperCase()}`);
                }
            });
        }

        // Popup detail
        if (popupBtn) {
            popupBtn.addEventListener('click', function() {
                const sidebar = document.getElementById('right-sidebar');
                if (sidebar) {
                    sidebar.classList.remove('translate-x-full');
                    announceToScreenReader('Membuka detail dokumen');
                }
            });
        }

        // Close player
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                const bottomPlayer = document.getElementById('bottom-audio-player');
                if (bottomPlayer) {
                    bottomPlayer.classList.add('hidden');
                }
                
                stopAllAudio();
                currentGlobalAudio = null;
                currentDocument = null;
                isPlaying = false;
                announceToScreenReader('Pemutar audio ditutup');
            });
        }

        // Close sidebar
        if (closeSidebarBtn) {
            closeSidebarBtn.addEventListener('click', function() {
                const sidebar = document.getElementById('right-sidebar');
                if (sidebar) {
                    sidebar.classList.add('translate-x-full');
                }
            });
        }

        // Audio ended event
        mainAudio.addEventListener('ended', function() {
            updatePlayButtonState(false);
            if (progressBar) progressBar.style.width = '0%';
            if (currentTimeEl) currentTimeEl.textContent = '00:00';
            isPlaying = false;
            announceToScreenReader('Audio selesai diputar');
        });

        function switchFormat(format) {
            if (!currentDocument) return;
            
            const wasPlaying = currentGlobalAudio && !currentGlobalAudio.paused;
            const currentTime = currentGlobalAudio ? currentGlobalAudio.currentTime : 0;
            
            currentFormat = format;
            
            // Update format button states
            if (formatMp3Btn && formatFlacBtn) {
                if (format === 'mp3') {
                    formatMp3Btn.classList.add('bg-gray-700');
                    formatMp3Btn.classList.remove('text-gray-400');
                    formatFlacBtn.classList.remove('bg-gray-700');
                    formatFlacBtn.classList.add('text-gray-400');
                } else {
                    formatFlacBtn.classList.add('bg-gray-700');
                    formatFlacBtn.classList.remove('text-gray-400');
                    formatMp3Btn.classList.remove('bg-gray-700');
                    formatMp3Btn.classList.add('text-gray-400');
                }
            }
            
            // Reload audio with new format
            if (currentGlobalAudio) {
                const audioUrl = `/documents/${currentDocument.id}/audio/${format}/stream`;
                currentGlobalAudio.innerHTML = '';
                const source = document.createElement('source');
                source.src = audioUrl;
                source.type = format === 'mp3' ? 'audio/mpeg' : 'audio/flac';
                currentGlobalAudio.appendChild(source);
                currentGlobalAudio.load();
                
                currentGlobalAudio.addEventListener('loadedmetadata', function() {
                    currentGlobalAudio.currentTime = currentTime;
                    if (wasPlaying) {
                        currentGlobalAudio.play().catch(console.error);
                    }
                }, { once: true });
            }
            
            // Update sidebar format display
            const sidebarFormat = document.getElementById('sidebar-audio-format');
            if (sidebarFormat) {
                sidebarFormat.textContent = format.toUpperCase();
            }
            
            announceToScreenReader(`Format audio diubah ke ${format.toUpperCase()}`);
        }

        // Make functions globally available for other scripts
        window.stopAllAudio = stopAllAudio;
        window.updatePlayerUI = updatePlayerUI;
        window.loadAndPlayAudio = loadAndPlayAudio;

        console.log('🎵 Enhanced Audio Player initialized successfully');
    }

    // Voice search initialization (BERSIH & TIDAK DUPLIKAT)
    function initializeVoiceSearch() {
        if (!('webkitSpeechRecognition' in window)) {
            console.warn("Browser tidak mendukung Web Speech API");
            return;
        }

        // Cegah inisialisasi ganda
        if (window.__voiceInitDone) return;
        window.__voiceInitDone = true;

        // === Helpers ===
        const hideModal = () => {
            const modal = document.getElementById('voice-search-modal');
            if (modal) modal.classList.add('hidden');
        };

        const openModal = () => {
            try { window.speechSynthesis.cancel(); } catch {}
            const modal = document.getElementById('voice-search-modal');
            if (modal) modal.classList.remove('hidden');
            try { wakeRec.stop(); } catch {}
            searchRec.start();
        };

        const speak = (text, cb = null) => {
            try {
                const utter = new SpeechSynthesisUtterance(text);
                utter.lang = "id-ID";
                utter.onend = () => { if (cb) cb(); };
                window.speechSynthesis.speak(utter);
            } catch (e) {
                console.warn("Speech synthesis error:", e);
                if (cb) cb();
            }
        };

        const extractNumber = (text) => {
            const m = text.match(/\d+/);
            if (m) return parseInt(m[0], 10);
            const map = {
                'satu':1,'dua':2,'tiga':3,'empat':4,'lima':5,
                'enam':6,'tujuh':7,'delapan':8,'sembilan':9,'sepuluh':10
            };
            for (const [w,n] of Object.entries(map)) {
                if (new RegExp(`\\b${w}\\b`).test(text)) return n;
            }
            return null;
        };

        const applyFilterParam = (key, value) => {
            const url = new URL(window.location.href);
            if (key === 'indicator' && isNaN(value)) {
                const curr = url.searchParams.get('query') || '';
                url.searchParams.set('query', `${curr} ${value}`.trim());
            } else {
                url.searchParams.set(key, value);
            }
            url.searchParams.set('voice', '1');
            window.location.href = url.toString();
        };

        // === Instansiasi recognitions ===
        const wakeRec = new webkitSpeechRecognition();
        wakeRec.continuous = true;
        wakeRec.interimResults = false;
        wakeRec.lang = 'id-ID';

        const searchRec = new webkitSpeechRecognition();
        searchRec.continuous = false;
        searchRec.interimResults = false;
        searchRec.lang = 'id-ID';

        window.commandRecognition = wakeRec;
        window.voiceRecognition = searchRec;

        // === Event search (query utama) ===
        searchRec.onresult = function(event) {
            const searchQuery = event.results[0][0].transcript;
            hideModal();

            const searchUrl = document.body.dataset.searchUrl || "/search";

            // Ambil data JSON untuk voice feedback
            fetch(searchUrl + `?query=${encodeURIComponent(searchQuery)}&voice=1`, {
                headers: { "Accept": "application/json" }
            })
            .then(res => res.json())
            .then(data => {
                if (data.voiceMessage) {
                    const utterance = new SpeechSynthesisUtterance(data.voiceMessage);
                    utterance.lang = "id-ID";
                    speechSynthesis.speak(utterance);
                }
            })
            .catch(err => console.error("Voice fetch error:", err))
            .finally(() => {
                // Langsung tampilkan hasil (tidak menunggu TTS selesai)
                window.location.href = searchUrl + `?query=${encodeURIComponent(searchQuery)}`;
            });
        };

        searchRec.onerror = function() {
            hideModal();
            alert('Pencarian suara gagal. Silakan coba lagi.');
            try { wakeRec.start(); } catch {}
        };

        searchRec.onend = function(event) {
            // kalau user nggak ngomong apa2 → tetap restart wakeRec
            hideModal();
            try { wakeRec.start(); } catch {}
        };

        // === Event wake + perintah lanjutan ===
        wakeRec.onresult = function(event) {
            const command = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();

            // Wake words lebih fleksibel
            if (command.includes('hai audio statistik') || 
                command.includes('hey audio statistik') || 
                command.includes('halo audio statistik')) {
                openModal();
                return;
            }

            // Perintah pilih/putar dokumen
            const num = extractNumber(command);
            if (num && (command.includes('pilih dokumen nomor') || command.startsWith('pilih nomor'))) {
                speak(`Membuka dokumen nomor ${num}`, () => {
                    const eyeBtns = document.querySelectorAll('.fa-eye');
                    if (eyeBtns[num - 1]) {
                        eyeBtns[num - 1].closest('a').click();
                    } else {
                        speak(`Dokumen nomor ${num} tidak ditemukan`);
                    }
                });
                return;
            }

            if (num && (command.includes('putar dokumen nomor') || command.startsWith('putar nomor'))) {
                speak(`Memutar dokumen nomor ${num}`, () => {
                    const playBtns = document.querySelectorAll('.play-document-btn');
                    if (playBtns[num - 1]) {
                        playBtns[num - 1].click();
                    } else {
                        speak(`Dokumen nomor ${num} tidak ditemukan atau belum siap diputar`);
                    }
                });
                return;
            }

            // Filter lanjutan
            if (/filter\s+publikasi/.test(command)) {
                speak("Menerapkan filter publikasi", () => {
                    applyFilterParam('type', 'publication');
                });
                return;
            }
            if (/filter\s*brs/.test(command)) {
                speak("Menerapkan filter BRS", () => {
                    applyFilterParam('type', 'brs');
                });
                return;
            }
            const yearMatch = command.match(/filter\s+tahun\s+(20\d{2})/);
            if (yearMatch) {
                speak(`Menerapkan filter tahun ${yearMatch[1]}`, () => {
                    applyFilterParam('year', yearMatch[1]);
                });
                return;
            }
            const indMatch = command.match(/^filter\s+(.+)$/);
            if (indMatch && !/publikasi|brs|tahun/.test(indMatch[1])) {
                const indikator = indMatch[1].trim();
                speak(`Menerapkan filter ${indikator}`, () => {
                    applyFilterParam('indicator', indikator);
                });
                return;
            }

            // 🔹 Tambahan: perintah "cari ..."
            if (command.startsWith('cari')) {
                const queryText = command.replace(/^cari\s*/, '').trim();
                if (queryText) {
                    speak(`Mencari ${queryText}`, () => {
                        const url = new URL(window.location.href);
                        const curr = url.searchParams.get('query') || '';
                        url.searchParams.set('query', `${curr} ${queryText}`.trim());
                        url.searchParams.set('voice', '1');
                        window.location.href = url.toString();
                    });
                }
                return;
            }
        };

        wakeRec.onerror = function() {
            setTimeout(() => { try { wakeRec.start(); } catch {} }, 800);
        };

        // === Tombol/Keyboard ===
        const triggerBtn = document.getElementById('voice-search-trigger');
        if (triggerBtn) triggerBtn.addEventListener('click', openModal);

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Control') {
                e.preventDefault();
                openModal();
            }
        });

        const stopBtn = document.getElementById('stop-listening');
        if (stopBtn) {
            stopBtn.addEventListener('click', function() {
                try { searchRec.stop(); } catch {}
                hideModal();
                try { wakeRec.start(); } catch {}
            });
        }

        // === Mulai standby ===
        try { wakeRec.start(); } catch (e) {
            console.error("Gagal memulai wakeRec:", e);
        }

        console.log("✅ Voice Search initialized (with TTS feedback)");
    }

    // Fungsi baca voiceMessage dari backend
    function speakMessage(message, onEnd = null) {
        if (!message) return;
        const utterance = new SpeechSynthesisUtterance(message);
        utterance.lang = "id-ID";
        utterance.onend = function() {
            if (onEnd) onEnd();
            // setelah selesai baca → nyalakan wake word lagi
            try { window.commandRecognition.start(); } catch {}
        };
        window.speechSynthesis.speak(utterance);
    }

    // Cek jika halaman search dipanggil dengan ?voice=1
    document.addEventListener("DOMContentLoaded", function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get("voice") === "1") {
            fetch(window.location.href, { headers: { "Accept": "application/json" } })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.voiceMessage) {
                        speakMessage(data.voiceMessage);
                    }
                })
                .catch(err => console.error("Voice message fetch error:", err));
        }
    });

    // Sticky navbar initialization
    function initializeStickyNavbar() {
        const header = document.querySelector('header');
        const body = document.body;
        let lastScrollTop = 0;
        let isScrollingDown = false;

        // Enhanced sticky navbar dengan scroll detection
        window.addEventListener('scroll', function() {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Add backdrop blur effect when scrolled
            if (scrollTop > 10) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }

            lastScrollTop = scrollTop;
        });

        // Smooth scroll untuk anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    const offsetTop = target.offsetTop - 80; // 80px offset untuk navbar
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Mobile menu enhanced animation
        const mobileMenuButton = document.getElementById('mobile-menu-button');
        const mobileMenu = document.getElementById('mobile-menu');
        
        if (mobileMenuButton && mobileMenu) {
            mobileMenuButton.addEventListener('click', function() {
                const isHidden = mobileMenu.classList.contains('hidden');
                
                if (isHidden) {
                    mobileMenu.classList.remove('hidden');
                    // Force reflow
                    mobileMenu.offsetHeight;
                    this.setAttribute('aria-expanded', 'true');
                    
                    // Change icon to X
                    const icon = this.querySelector('i');
                    icon.classList.replace('fa-bars', 'fa-times');
                } else {
                    mobileMenu.classList.add('hidden');
                    this.setAttribute('aria-expanded', 'false');
                    
                    // Change icon back to bars
                    const icon = this.querySelector('i');
                    icon.classList.replace('fa-times', 'fa-bars');
                }
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', function(e) {
                if (!mobileMenuButton.contains(e.target) && !mobileMenu.contains(e.target)) {
                    if (!mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                        mobileMenuButton.setAttribute('aria-expanded', 'false');
                        
                        const icon = mobileMenuButton.querySelector('i');
                        icon.classList.replace('fa-times', 'fa-bars');
                    }
                }
            });

            // Close mobile menu on escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && !mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                    mobileMenuButton.setAttribute('aria-expanded', 'false');
                    mobileMenuButton.focus();
                    
                    const icon = mobileMenuButton.querySelector('i');
                    icon.classList.replace('fa-times', 'fa-bars');
                }
            });
        }

        // Ensure no content is hidden behind navbar
        function adjustContentForStickyNavbar() {
            const headerHeight = header.offsetHeight;
            const firstContentElement = document.querySelector('main > *:first-child');
            
            if (firstContentElement && !firstContentElement.classList.contains('sticky-navbar-compensation')) {
                firstContentElement.style.paddingTop = '2rem'; // Additional padding
            }
        }

        // Run on load and resize
        adjustContentForStickyNavbar();
        window.addEventListener('resize', adjustContentForStickyNavbar);

        console.log('🔝 Sticky navbar initialized');
    }

    function formatTime(seconds) {
        if (!seconds || isNaN(seconds)) return '00:00';
        
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }

    function announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            if (document.body.contains(announcement)) {
                document.body.removeChild(announcement);
            }
        }, 1000);
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Skip shortcuts if user is typing in an input
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) {
            return;
        }
        
        switch(e.key) {
            case 'h':
                if (!e.ctrlKey && !e.altKey && !e.metaKey) {
                    window.location.href = '/';
                    announceToScreenReader('Menuju ke beranda');
                }
                break;
            case 'p':
                if (!e.ctrlKey && !e.altKey && !e.metaKey) {
                    window.location.href = '/publikasi';
                    announceToScreenReader('Menuju ke halaman publikasi');
                }
                break;
            case 'b':
                if (!e.ctrlKey && !e.altKey && !e.metaKey) {
                    window.location.href = '/brs';
                    announceToScreenReader('Menuju ke halaman BRS');
                }
                break;
            case ' ':
                if (currentDocument && !e.ctrlKey && !e.altKey && !e.metaKey) {
                    e.preventDefault();
                    const playBtn = document.getElementById('play-pause-main-btn');
                    if (playBtn) playBtn.click();
                }
                break;
            case '?':
                if (!e.ctrlKey && !e.altKey && !e.metaKey) {
                    showKeyboardHelp();
                }
                break;
        }
    });

    function showKeyboardHelp() {
        const helpModal = document.createElement('div');
        helpModal.className = 'fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center';
        helpModal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md mx-4">
                <h3 class="text-lg font-semibold mb-4 text-sound">Pintasan Keyboard</h3>
                <div class="space-y-2 text-sm">
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">H</kbd>
                        <span class="text-sound">Beranda</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">P</kbd>
                        <span class="text-sound">Publikasi</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">B</kbd>
                        <span class="text-sound">BRS</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">Ctrl</kbd>
                        <span class="text-sound">Pencarian Suara</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">Ctrl + T</kbd>
                        <span class="text-sound">Toggle Suara Hover</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">Spasi</kbd>
                        <span class="text-sound">Putar/Jeda Audio</span>
                    </div>
                    <div class="flex justify-between">
                        <kbd class="px-2 py-1 bg-gray-100 rounded text-xs">?</kbd>
                        <span class="text-sound">Bantuan ini</span>
                    </div>
                </div>
                <button onclick="this.closest('.fixed').remove()" 
                        class="mt-4 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sound">
                    Tutup
                </button>
            </div>
        `;
        
        document.body.appendChild(helpModal);
        announceToScreenReader('Menampilkan bantuan pintasan keyboard');
    }

    // Global error handler for audio-related errors
    window.addEventListener('error', function(e) {
        if (e.message && e.message.includes('getElementById')) {
            console.error('🚨 getElementById error detected:', e.message);
            console.error('🔍 Error context:', e.filename, e.lineno, e.colno);
            
            // Show user-friendly message for audio-related errors
            if (e.message.includes('playDocumentAudio')) {
                setTimeout(() => {
                    if (!window.audioErrorNotified) {
                        window.audioErrorNotified = true;
                        announceToScreenReader('Terjadi masalah dengan sistem audio. Silakan refresh halaman.');
                    }
                }, 100);
            }
        }
    });

    console.log('🎵 Integrated Audio System with Enhanced Features and Error Fixes initialized');

   // Export functions globally
    window.AudioSystem = {
        playDocumentAudio: window.playDocumentAudio,
        stopAllAudio: window.stopAllAudio,
        playTextHoverSound: window.playTextHoverSound,
        announceToScreenReader: window.announceToScreenReader
    };

    // Enhanced Audio Player with Backend Integration
    class AudioPlayerManager {
        constructor() {
            this.currentDocument = null;
            this.currentAudio = null;
            this.isPlaying = false;
            this.currentFormat = 'mp3';
            this.progressUpdateInterval = null;
            this.retryCount = 0;
            this.maxRetries = 3;
            
            this.initializePlayer();
        }

        initializePlayer() {
            console.log('🎵 Initializing Enhanced Audio Player Manager');
            
            // Create main audio element if not exists
            if (!document.getElementById('main-audio')) {
                const audio = document.createElement('audio');
                audio.id = 'main-audio';
                audio.preload = 'metadata';
                document.body.appendChild(audio);
            }

            this.currentAudio = document.getElementById('main-audio');
            this.setupAudioEvents();
            this.setupKeyboardShortcuts();
        }

        setupAudioEvents() {
            if (!this.currentAudio) return;

            this.currentAudio.addEventListener('loadstart', () => {
                console.log('🔄 Audio loading started');
                this.updateLoadingState(true);
            });

            this.currentAudio.addEventListener('loadedmetadata', () => {
                console.log('📊 Audio metadata loaded');
                this.updatePlayerDisplay();
            });

            this.currentAudio.addEventListener('canplay', () => {
                console.log('▶️ Audio can play');
                this.updateLoadingState(false);
            });

            this.currentAudio.addEventListener('play', () => {
                console.log('🎶 Audio play started');
                this.isPlaying = true;
                this.updatePlayPauseButton();
                this.startProgressTracking();
            });

            this.currentAudio.addEventListener('pause', () => {
                console.log('⏸️ Audio paused');
                this.isPlaying = false;
                this.updatePlayPauseButton();
                this.stopProgressTracking();
            });

            this.currentAudio.addEventListener('ended', () => {
                console.log('🏁 Audio ended');
                this.handleAudioEnded();
            });

            this.currentAudio.addEventListener('error', (e) => {
                console.error('❌ Audio error:', e);
                this.handleAudioError(e);
            });

            this.currentAudio.addEventListener('timeupdate', () => {
                this.updateProgressBar();
            });
        }

        setupKeyboardShortcuts() {
            document.addEventListener('keydown', (e) => {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return; // Don't trigger shortcuts when typing
                }

                switch(e.code) {
                    case 'Space':
                        e.preventDefault();
                        this.togglePlayPause();
                        break;
                    case 'ArrowLeft':
                        e.preventDefault();
                        this.seekBackward(10);
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        this.seekForward(10);
                        break;
                    case 'ArrowUp':
                        e.preventDefault();
                        this.adjustVolume(0.1);
                        break;
                    case 'ArrowDown':
                        e.preventDefault();
                        this.adjustVolume(-0.1);
                        break;
                }
            });
        }

        async playDocument(documentId, options = {}) {
            try {
                console.log('🎵 Starting playDocument for ID:', documentId);
                
                // Stop current playback
                this.stopCurrent();
                
                // Show loading state
                this.updateLoadingState(true);
                
                // Get audio metadata from backend
                const metadata = await this.fetchAudioMetadata(documentId);
                
                if (!metadata.can_play) {
                    throw new Error('This document cannot be played');
                }

                this.currentDocument = metadata;
                
                // Update UI
                this.updatePlayerUI(metadata);
                this.showPlayer();
                
                // Load and play audio
                await this.loadAndPlayAudio(metadata, options);
                
                // Announce to screen reader
                this.announceToScreenReader(`Playing: ${metadata.title}`);
                
            } catch (error) {
                console.error('❌ Failed to play document:', error);
                this.handlePlaybackError(error);
            }
        }

        async fetchAudioMetadata(documentId) {
            try {
                const response = await fetch(`/audio/metadata/${documentId}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const result = await response.json();
                
                if (!result.success) {
                    throw new Error(result.message || 'Failed to get audio metadata');
                }

                return result.data;
                
            } catch (error) {
                console.error('❌ Failed to fetch audio metadata:', error);
                throw error;
            }
        }

        async loadAndPlayAudio(metadata, options = {}) {
            try {
                // Determine best format to use
                const format = this.selectBestFormat(metadata.audio.formats_available, options.preferredFormat);
                
                if (!format) {
                    throw new Error('No playable audio format available');
                }

                this.currentFormat = format;
                const audioUrl = metadata.audio[`${format}_url`];
                
                console.log(`🎵 Loading ${format.toUpperCase()} audio:`, audioUrl);
                
                // Set audio source
                this.currentAudio.src = audioUrl;
                
                // Load audio
                await new Promise((resolve, reject) => {
                    const loadTimeout = setTimeout(() => {
                        reject(new Error('Audio loading timeout'));
                    }, 30000); // 30 second timeout

                    this.currentAudio.addEventListener('loadeddata', () => {
                        clearTimeout(loadTimeout);
                        resolve();
                    }, { once: true });

                    this.currentAudio.addEventListener('error', () => {
                        clearTimeout(loadTimeout);
                        reject(new Error('Audio loading failed'));
                    }, { once: true });

                    this.currentAudio.load();
                });

                // Resume from saved progress if available
                await this.resumeFromSavedProgress();
                
                // Start playback
                await this.currentAudio.play();
                
                console.log('✅ Audio playback started successfully');
                
            } catch (error) {
                console.error('❌ Failed to load and play audio:', error);
                throw error;
            }
        }

        selectBestFormat(availableFormats, preferredFormat = null) {
            if (!availableFormats || availableFormats.length === 0) {
                return null;
            }

            // If preferred format is available, use it
            if (preferredFormat && availableFormats.includes(preferredFormat)) {
                return preferredFormat;
            }

            // Default preference: MP3 first (better compatibility), then FLAC
            const formatPriority = ['mp3', 'flac'];
            
            for (const format of formatPriority) {
                if (availableFormats.includes(format)) {
                    return format;
                }
            }

            // Fallback to first available format
            return availableFormats[0];
        }

        async resumeFromSavedProgress() {
            if (!this.currentDocument) return;

            try {
                const response = await fetch(`/audio/progress/${this.currentDocument.id}`, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.success && result.data && result.data.current_time > 10) {
                        // Only resume if more than 10 seconds in
                        this.currentAudio.currentTime = result.data.current_time;
                        console.log(`⏩ Resumed from ${result.data.current_time}s`);
                    }
                }
            } catch (error) {
                console.warn('⚠️ Failed to load saved progress:', error);
                // Don't throw, just continue without resuming
            }
        }

        stopCurrent() {
            if (this.currentAudio && !this.currentAudio.paused) {
                this.currentAudio.pause();
                this.currentAudio.currentTime = 0;
            }

            this.stopProgressTracking();
            this.isPlaying = false;
            this.retryCount = 0;
        }

        togglePlayPause() {
            if (!this.currentAudio || !this.currentDocument) {
                console.warn('⚠️ No audio loaded');
                return;
            }

            if (this.isPlaying) {
                this.currentAudio.pause();
            } else {
                this.currentAudio.play().catch(error => {
                    console.error('❌ Play failed:', error);
                    this.handleAudioError(error);
                });
            }
        }

        seekForward(seconds = 10) {
            if (this.currentAudio && this.currentDocument) {
                this.currentAudio.currentTime = Math.min(
                    this.currentAudio.currentTime + seconds,
                    this.currentAudio.duration || 0
                );
            }
        }

        seekBackward(seconds = 10) {
            if (this.currentAudio && this.currentDocument) {
                this.currentAudio.currentTime = Math.max(
                    this.currentAudio.currentTime - seconds,
                    0
                );
            }
        }

        adjustVolume(delta) {
            if (this.currentAudio) {
                this.currentAudio.volume = Math.max(0, Math.min(1, this.currentAudio.volume + delta));
                this.updateVolumeDisplay();
            }
        }

        setPlaybackRate(rate) {
            if (this.currentAudio) {
                this.currentAudio.playbackRate = rate;
                this.updatePlaybackRateDisplay();
            }
        }

        updatePlayerUI(metadata) {
            // Update title
            const titleElement = document.querySelector('#bottom-audio-player .track-title');
            if (titleElement) {
                titleElement.textContent = metadata.title;
            }

            // Update description/subtitle
            const subtitleElement = document.querySelector('#bottom-audio-player .track-subtitle');
            if (subtitleElement) {
                subtitleElement.textContent = metadata.description || `${metadata.type} ${metadata.year}`;
            }

            // Update cover image
            const coverElement = document.querySelector('#bottom-audio-player .track-cover');
            if (coverElement) {
                if (metadata.cover_url) {
                    coverElement.src = metadata.cover_url;
                    coverElement.style.display = 'block';
                } else {
                    coverElement.style.display = 'none';
                }
            }

            // Update duration
            const durationElement = document.querySelector('#bottom-audio-player .duration');
            if (durationElement) {
                durationElement.textContent = metadata.audio.duration_formatted || '00:00';
            }

            // Update format indicator
            const formatElement = document.querySelector('#bottom-audio-player .format-indicator');
            if (formatElement) {
                formatElement.textContent = this.currentFormat.toUpperCase();
            }
        }

        updatePlayPauseButton() {
            const playBtn = document.querySelector('#bottom-audio-player .play-pause-btn i');
            if (playBtn) {
                if (this.isPlaying) {
                    playBtn.className = 'fas fa-pause';
                } else {
                    playBtn.className = 'fas fa-play';
                }
            }
        }

        updateLoadingState(isLoading) {
            const loadingIndicator = document.querySelector('#bottom-audio-player .loading-indicator');
            const playPauseBtn = document.querySelector('#bottom-audio-player .play-pause-btn');
            
            if (loadingIndicator) {
                loadingIndicator.style.display = isLoading ? 'block' : 'none';
            }
            
            if (playPauseBtn) {
                playPauseBtn.disabled = isLoading;
            }
        }

        updateProgressBar() {
            if (!this.currentAudio || !this.currentDocument) return;

            const progress = document.querySelector('#bottom-audio-player .progress-bar');
            const currentTimeEl = document.querySelector('#bottom-audio-player .current-time');
            
            if (progress && this.currentAudio.duration) {
                const percentage = (this.currentAudio.currentTime / this.currentAudio.duration) * 100;
                progress.style.width = `${percentage}%`;
            }
            
            if (currentTimeEl) {
                currentTimeEl.textContent = this.formatTime(this.currentAudio.currentTime);
            }
        }

        updateVolumeDisplay() {
            const volumeBar = document.querySelector('#bottom-audio-player .volume-bar');
            const volumeIcon = document.querySelector('#bottom-audio-player .volume-btn i');
            
            if (volumeBar && this.currentAudio) {
                volumeBar.style.width = `${this.currentAudio.volume * 100}%`;
            }
            
            if (volumeIcon && this.currentAudio) {
                if (this.currentAudio.volume === 0) {
                    volumeIcon.className = 'fas fa-volume-mute';
                } else if (this.currentAudio.volume < 0.5) {
                    volumeIcon.className = 'fas fa-volume-down';
                } else {
                    volumeIcon.className = 'fas fa-volume-up';
                }
            }
        }

        updatePlaybackRateDisplay() {
            const rateElement = document.querySelector('#bottom-audio-player .playback-rate');
            if (rateElement && this.currentAudio) {
                rateElement.textContent = `${this.currentAudio.playbackRate}x`;
            }
        }

        startProgressTracking() {
            this.stopProgressTracking(); // Clear any existing interval
            
            this.progressUpdateInterval = setInterval(() => {
                this.saveProgressToBackend();
            }, 10000); // Save progress every 10 seconds
        }

        stopProgressTracking() {
            if (this.progressUpdateInterval) {
                clearInterval(this.progressUpdateInterval);
                this.progressUpdateInterval = null;
            }
        }

        async saveProgressToBackend() {
            if (!this.currentDocument || !this.currentAudio) return;

            try {
                await fetch(`/audio/progress/${this.currentDocument.id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
                    },
                    body: JSON.stringify({
                        current_time: this.currentAudio.currentTime,
                        duration: this.currentAudio.duration || this.currentDocument.audio.duration
                    })
                });
            } catch (error) {
                console.warn('⚠️ Failed to save progress:', error);
                // Don't throw, just log warning
            }
        }

        showPlayer() {
            const bottomPlayer = document.getElementById('bottom-audio-player');
            if (bottomPlayer) {
                bottomPlayer.classList.remove('hidden');
                bottomPlayer.classList.add('visible');
            }
        }

        hidePlayer() {
            const bottomPlayer = document.getElementById('bottom-audio-player');
            if (bottomPlayer) {
                bottomPlayer.classList.add('hidden');
                bottomPlayer.classList.remove('visible');
            }
        }

        handleAudioEnded() {
            this.isPlaying = false;
            this.updatePlayPauseButton();
            this.stopProgressTracking();
            
            // Reset progress
            this.currentAudio.currentTime = 0;
            this.updateProgressBar();
            
            console.log('🏁 Audio playback completed');
            
            // Optional: Auto-play next document in playlist
            // this.playNextInPlaylist();
        }

        async handleAudioError(error) {
            console.error('❌ Audio error occurred:', error);
            
            this.updateLoadingState(false);
            
            if (this.retryCount < this.maxRetries) {
                this.retryCount++;
                console.log(`🔄 Retrying audio playback (attempt ${this.retryCount}/${this.maxRetries})`);
                
                // Try with different format if available
                const alternativeFormat = this.currentFormat === 'mp3' ? 'flac' : 'mp3';
                if (this.currentDocument?.audio.formats_available.includes(alternativeFormat)) {
                    try {
                        await this.loadAndPlayAudio(this.currentDocument, { preferredFormat: alternativeFormat });
                        return;
                    } catch (retryError) {
                        console.error('❌ Retry with alternative format failed:', retryError);
                    }
                }
                
                // Retry with same format after delay
                setTimeout(() => {
                    if (this.currentDocument) {
                        this.loadAndPlayAudio(this.currentDocument).catch(retryError => {
                            console.error('❌ Retry failed:', retryError);
                            this.handlePlaybackError(retryError);
                        });
                    }
                }, 2000);
            } else {
                this.handlePlaybackError(error);
            }
        }

        handlePlaybackError(error) {
            console.error('💥 Playback failed permanently:', error);
            
            this.updateLoadingState(false);
            this.retryCount = 0;
            
            // Show error message to user
            this.showErrorMessage(`Failed to play audio: ${error.message}`);
            
            // Hide player if no current document
            if (!this.currentDocument) {
                this.hidePlayer();
            }
        }

        showErrorMessage(message) {
            // Show toast notification or alert
            if (typeof showToast === 'function') {
                showToast(message, 'error');
            } else {
                alert(message);
            }
        }

        announceToScreenReader(message) {
            const announcement = document.createElement('div');
            announcement.setAttribute('aria-live', 'polite');
            announcement.setAttribute('aria-atomic', 'true');
            announcement.className = 'sr-only';
            announcement.textContent = message;
            
            document.body.appendChild(announcement);
            
            setTimeout(() => {
                document.body.removeChild(announcement);
            }, 1000);
        }

        formatTime(seconds) {
            if (isNaN(seconds) || seconds < 0) return '00:00';
            
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = Math.floor(seconds % 60);
            
            return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
        }

        // Public API methods for backward compatibility
        async switchFormat(format) {
            if (!this.currentDocument || !this.currentDocument.audio.formats_available.includes(format)) {
                console.warn('⚠️ Format not available:', format);
                return;
            }

            const currentTime = this.currentAudio ? this.currentAudio.currentTime : 0;
            
            try {
                await this.loadAndPlayAudio(this.currentDocument, { preferredFormat: format });
                
                // Resume from current position
                if (this.currentAudio && currentTime > 0) {
                    this.currentAudio.currentTime = currentTime;
                }
            } catch (error) {
                console.error('❌ Failed to switch format:', error);
                this.showErrorMessage(`Failed to switch to ${format.toUpperCase()} format`);
            }
        }

        getCurrentDocument() {
            return this.currentDocument;
        }

        isPlayerActive() {
            return this.currentDocument !== null;
        }

        getPlaybackState() {
            return {
                isPlaying: this.isPlaying,
                currentTime: this.currentAudio ? this.currentAudio.currentTime : 0,
                duration: this.currentAudio ? this.currentAudio.duration : 0,
                volume: this.currentAudio ? this.currentAudio.volume : 1,
                playbackRate: this.currentAudio ? this.currentAudio.playbackRate : 1,
                format: this.currentFormat
            };
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        audioPlayerManager = new AudioPlayerManager();
        
        // Expose global functions for backward compatibility
        window.playDocumentAudio = function(documentData) {
            // Handle both old format (object with audio URLs) and new format (just document ID)
            if (typeof documentData === 'object' && documentData.id) {
                return audioPlayerManager.playDocument(documentData.id);
            } else if (typeof documentData === 'number' || typeof documentData === 'string') {
                return audioPlayerManager.playDocument(documentData);
            } else {
                console.error('❌ Invalid document data provided to playDocumentAudio');
            }
        };
        
        window.stopAudio = function() {
            audioPlayerManager.stopCurrent();
            audioPlayerManager.hidePlayer();
        };
        
        window.toggleAudioPlayPause = function() {
            audioPlayerManager.togglePlayPause();
        };
        
        window.switchAudioFormat = function(format) {
            return audioPlayerManager.switchFormat(format);
        };
        
        window.getAudioPlayerState = function() {
            return audioPlayerManager.getPlaybackState();
        };
    });

    // Enhanced click handlers for audio player controls
    document.addEventListener('click', function(e) {
        // Play/Pause button
        if (e.target.closest('#bottom-audio-player .play-pause-btn')) {
            e.preventDefault();
            audioPlayerManager.togglePlayPause();
        }
        
        // Stop button
        if (e.target.closest('#bottom-audio-player .stop-btn')) {
            e.preventDefault();
            audioPlayerManager.stopCurrent();
            audioPlayerManager.hidePlayer();
        }
        
        // Forward/Backward buttons
        if (e.target.closest('#bottom-audio-player .forward-btn')) {
            e.preventDefault();
            audioPlayerManager.seekForward(10);
        }
        
        if (e.target.closest('#bottom-audio-player .backward-btn')) {
            e.preventDefault();
            audioPlayerManager.seekBackward(10);
        }
        
        // Format switch buttons
        if (e.target.closest('#bottom-audio-player .format-mp3-btn')) {
            e.preventDefault();
            audioPlayerManager.switchFormat('mp3');
        }
        
        if (e.target.closest('#bottom-audio-player .format-flac-btn')) {
            e.preventDefault();
            audioPlayerManager.switchFormat('flac');
        }
        
        // Volume control
        if (e.target.closest('#bottom-audio-player .volume-btn')) {
            e.preventDefault();
            if (audioPlayerManager.currentAudio) {
                audioPlayerManager.currentAudio.muted = !audioPlayerManager.currentAudio.muted;
                audioPlayerManager.updateVolumeDisplay();
            }
        }
        
        // Speed control
        if (e.target.closest('#bottom-audio-player .speed-btn')) {
            e.preventDefault();
            const currentRate = audioPlayerManager.currentAudio ? audioPlayerManager.currentAudio.playbackRate : 1;
            const rates = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
            const currentIndex = rates.indexOf(currentRate);
            const nextRate = rates[(currentIndex + 1) % rates.length];
            audioPlayerManager.setPlaybackRate(nextRate);
        }
    });

    // Progress bar click handler
    document.addEventListener('click', function(e) {
        const progressContainer = e.target.closest('#bottom-audio-player .progress-container');
        if (progressContainer && audioPlayerManager.currentAudio && audioPlayerManager.currentAudio.duration) {
            const rect = progressContainer.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const percentage = clickX / rect.width;
            const newTime = percentage * audioPlayerManager.currentAudio.duration;
            audioPlayerManager.currentAudio.currentTime = Math.max(0, Math.min(newTime, audioPlayerManager.currentAudio.duration));
        }
    });

    // Volume bar click handler
    document.addEventListener('click', function(e) {
        const volumeContainer = e.target.closest('#bottom-audio-player .volume-container');
        if (volumeContainer && audioPlayerManager.currentAudio) {
            const rect = volumeContainer.getBoundingClientRect();
            const clickX = e.clientX - rect.left;
            const percentage = Math.max(0, Math.min(1, clickX / rect.width));
            audioPlayerManager.currentAudio.volume = percentage;
            audioPlayerManager.updateVolumeDisplay();
        }
    });

    console.log('✅ Enhanced Audio Player Manager loaded successfully');
})();