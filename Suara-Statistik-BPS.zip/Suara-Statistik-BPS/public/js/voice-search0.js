(function() {
    'use strict';
    
    // Namespace management
    window.AudioStatistik = window.AudioStatistik || {};
    window.AudioStatistik.Voice = window.AudioStatistik.Voice || {};
    
    function shouldDisableVoiceSearch() {
        const currentPath = window.location.pathname;
        const excludedPages = [
            '/brs',
            '/publikasi',
            'documents/brs',
            'documents/publications'
        ];
        
        return excludedPages.some(page => currentPath.includes(page));
    }

    // Early exit if on excluded pages
    if (shouldDisableVoiceSearch()) {
        console.log('⏸️ Voice search disabled on BRS/Publication page');
        
        // Create minimal compatibility objects
        window.AudioSystem = window.AudioSystem || {};
        window.AudioSystem.initializeVoiceSearch = function(searchRoute) {
            console.log('⏸️ Voice search init skipped on BRS/Publication page');
            return this;
        };
        
        window.voiceCommand = window.voiceCommand || {};
        window.voiceCommand.init = function() {
            console.log('⏸️ Voice command init skipped on BRS/Publication page');
            return this;
        };
        
        // Create dummy voice search instance in namespace
        window.AudioStatistik = window.AudioStatistik || {};
        window.AudioStatistik.Voice = window.AudioStatistik.Voice || {};
        window.AudioStatistik.Voice.Search = {
            isDisabled: true,
            forceStop: () => console.log('⏸️ Voice search already disabled'),
            cleanup: () => console.log('⏸️ Voice search already disabled'),
            init: () => console.log('⏸️ Voice search disabled on this page')
        };
        
        // Stop further script execution
        return;
    }
    // Prevent double initialization
    if (window.AudioStatistik.Voice.Search) {
        console.log('🔄 Voice Search already initialized');
        return;
    }

    class VoiceSearch {
        constructor() {
            this.recognition = null;
            this.wakeRecognition = null;
            this.isListening = false;
            this.isWakeListening = false;
            this.isSupported = 'webkitSpeechRecognition' in window;
            this.modal = null;
            this.searchUrl = '/search';
            this.name = 'voice-search';
            
            this.wakeWords = ['hai audio statistik', 'hey audio statistik', 'audio statistik'];
            this.isInitialized = false;
        }

        async init() {
            if (!this.isSupported) {
                console.log('ℹ️ Voice search not supported');
                return;
            }

            if (this.isInitialized) {
                console.log('🔄 Voice search already initialized');
                return;
            }

            console.log('🎤 Initializing Voice Search with Coordination');
            
            // Register dengan voice coordinator
            if (window.AudioStatistik.VoiceCoordinator) {
                window.AudioStatistik.VoiceCoordinator.register(this.name, this);
            }
            
            this.setupModal();
            this.setupWakeWordRecognition();
            this.setupSearchRecognition();
            this.setupVoiceButtons();
            this.setupKeyboardShortcuts();
            this.startWakeWordListening();
            this.setupCompatibilityBridge();
            
            this.isInitialized = true;
            
            // Fire ready event
            document.dispatchEvent(new CustomEvent('voiceSearchReady', {
                detail: { instance: this }
            }));
        }

        setupModal() {
            this.modal = document.getElementById('voice-search-modal');
            if (!this.modal) {
                console.warn('⚠️ Voice search modal not found');
                return;
            }

            // Setup modal close events
            this.modal.addEventListener('click', (e) => {
                if (e.target === this.modal) {
                    this.closeModal();
                }
            });

            const stopBtn = document.getElementById('stop-listening');
            if (stopBtn) {
                stopBtn.addEventListener('click', () => this.closeModal());
            }

            // ESC key to close
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && !this.modal.classList.contains('hidden')) {
                    this.closeModal();
                }
            });
        }

        setupWakeWordRecognition() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.wakeRecognition = new SpeechRecognition();
            
            this.wakeRecognition.continuous = true;
            this.wakeRecognition.interimResults = false;
            this.wakeRecognition.lang = 'id-ID';
            
            this.wakeRecognition.onresult = (event) => {
                const transcript = event.results[event.results.length - 1][0].transcript.toLowerCase().trim();
                console.log('🎯 Wake word detected:', transcript);
                
                if (this.wakeWords.some(word => transcript.includes(word))) {
                    this.handleWakeWordDetected();
                }
            };

            this.wakeRecognition.onerror = (event) => {
                // Only log non-aborted errors
                if (event.error !== 'aborted' && event.error !== 'no-speech') {
                    console.warn('⚠️ Wake word error:', event.error);
                    setTimeout(() => this.restartWakeWordListening(), 2000);
                }
            };

            this.wakeRecognition.onend = () => {
                this.isWakeListening = false;
                if (!this.isListening && window.AudioStatistik.VoiceCoordinator?.canUseRecognition(this.name)) {
                    setTimeout(() => this.restartWakeWordListening(), 1000);
                }
            };
        }

        setupSearchRecognition() {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            this.recognition.continuous = false;
            this.recognition.interimResults = true;
            this.recognition.lang = 'id-ID';
            
            this.recognition.onstart = () => {
                console.log('🎤 Voice search started');
                this.isListening = true;
                this.updateVoiceButtons(true);
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[event.results.length - 1][0].transcript;
                console.log('🔍 Search query:', transcript);
                
                // Update modal text if exists
                const modalText = document.querySelector('#voice-search-modal p');
                if (modalText) {
                    modalText.textContent = `Mendengar: "${transcript}"`;
                }
                
                if (event.results[event.results.length - 1].isFinal) {
                    this.performSearch(transcript);
                }
            };

            this.recognition.onerror = (event) => {
                if (event.error !== 'aborted') {
                    console.warn('⚠️ Voice search error:', event.error);
                }
                this.isListening = false;
                this.updateVoiceButtons(false);
                this.closeModal();
                this.restartWakeWordListening();
            };

            this.recognition.onend = () => {
                console.log('🛑 Voice search ended');
                this.isListening = false;
                this.updateVoiceButtons(false);
                this.closeModal();
                this.restartWakeWordListening();
            };
        }

        setupVoiceButtons() {
            // Find all voice search buttons
            const buttons = document.querySelectorAll('[data-voice-search], .voice-search-btn, #voice-search-btn, #voice-search-floating');
            
            buttons.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.toggleVoiceSearch();
                });
                
                // Show button if voice is supported
                if (this.isSupported) {
                    button.style.display = 'inline-flex';
                }
            });
        }

        setupKeyboardShortcuts() {
            document.addEventListener('keydown', (event) => {
                // Ctrl key untuk voice search
                if (event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey) {
                    // Don't trigger on input fields
                    if (event.target.matches('input, textarea, select')) return;
                    
                    event.preventDefault();
                    this.toggleVoiceSearch();
                }
            });
        }

        handleWakeWordDetected() {
            console.log('🎯 Wake word detected - requesting voice search access');
            
            // Request recognition access dengan priority
            if (window.AudioStatistik.VoiceCoordinator) {
                const granted = window.AudioStatistik.VoiceCoordinator.requestWithPriority(this.name, () => {
                    this.openModal();
                });
                
                if (!granted) {
                    console.log('❌ Voice search access denied due to priority');
                    return;
                }
            } else {
                this.openModal();
            }
        }

        toggleVoiceSearch() {
            if (this.isListening) {
                this.stopVoiceSearch();
            } else {
                // Request recognition access
                if (window.AudioStatistik.VoiceCoordinator) {
                    const granted = window.AudioStatistik.VoiceCoordinator.requestWithPriority(this.name, () => {
                        this.openModal();
                    });
                    
                    if (!granted) {
                        console.log('❌ Voice search access denied');
                        return;
                    }
                } else {
                    this.openModal();
                }
            }
        }

        openModal() {
            if (!this.modal) return;
            
            this.stopWakeWordListening();
            this.modal.classList.remove('hidden');
            
            // Reset modal text
            const modalText = this.modal.querySelector('p');
            if (modalText) {
                modalText.textContent = 'Katakan pencarian Anda atau "Hai Audio Statistik"...';
            }
            
            // Start voice recognition
            setTimeout(() => {
                this.startVoiceSearch();
            }, 300);
        }

        closeModal() {
            if (!this.modal) return;
            
            this.modal.classList.add('hidden');
            this.stopVoiceSearch();
            
            // Release recognition access
            if (window.AudioStatistik.VoiceCoordinator) {
                window.AudioStatistik.VoiceCoordinator.releaseRecognition(this.name);
            }
            
            this.restartWakeWordListening();
        }

        startVoiceSearch() {
            if (!this.recognition || this.isListening) return;
            
            try {
                this.recognition.start();
            } catch (error) {
                console.error('❌ Failed to start voice search:', error);
                this.closeModal();
            }
        }

        stopVoiceSearch() {
            if (this.recognition && this.isListening) {
                try {
                    this.recognition.stop();
                } catch (error) {
                    console.warn('⚠️ Error stopping voice search:', error);
                }
            }
            this.isListening = false;
            this.updateVoiceButtons(false);
        }

        startWakeWordListening() {
            // Check if we can use recognition
            if (!window.AudioStatistik.VoiceCoordinator?.canUseRecognition(this.name)) {
                console.log('⏸️ Voice search waiting for recognition access');
                setTimeout(() => this.startWakeWordListening(), 2000);
                return;
            }

            if (!this.wakeRecognition || this.isWakeListening || this.isListening) return;
            
            // Request recognition access for wake word
            if (window.AudioStatistik.VoiceCoordinator) {
                const granted = window.AudioStatistik.VoiceCoordinator.requestRecognition(this.name);
                if (!granted) {
                    setTimeout(() => this.startWakeWordListening(), 2000);
                    return;
                }
            }
            
            try {
                this.isWakeListening = true;
                this.wakeRecognition.start();
                console.log('👂 Wake word listening started');
            } catch (error) {
                console.warn('⚠️ Could not start wake word listening:', error);
                this.isWakeListening = false;
                setTimeout(() => this.startWakeWordListening(), 1000);
            }
        }

        stopWakeWordListening() {
            if (this.wakeRecognition && this.isWakeListening) {
                try {
                    this.wakeRecognition.stop();
                } catch (error) {
                    console.warn('⚠️ Error stopping wake word listening:', error);
                }
            }
            this.isWakeListening = false;
        }

        restartWakeWordListening() {
            if (!this.isListening && !this.isWakeListening) {
                setTimeout(() => {
                    this.startWakeWordListening();
                }, 1000);
            }
        }

        performSearch(query) {
            if (!query.trim()) {
                this.closeModal();
                return;
            }
            
            console.log('🔍 Performing search:', query);
            
            // Close modal immediately
            this.closeModal();
            
            // Navigate to search with voice parameter
            const searchUrl = new URL(this.searchUrl, window.location.origin);
            searchUrl.searchParams.set('search', query.trim());
            searchUrl.searchParams.set('voice', '1');
            
            window.location.href = searchUrl.toString();
        }

        updateVoiceButtons(isActive) {
            const buttons = document.querySelectorAll('[data-voice-search], .voice-search-btn, #voice-search-btn, #voice-search-floating');
            
            buttons.forEach(button => {
                if (isActive) {
                    button.classList.add('listening', 'active', 'text-red-600');
                    button.classList.remove('text-gray-700', 'text-gray-400');
                } else {
                    button.classList.remove('listening', 'active', 'text-red-600');
                    button.classList.add('text-gray-700');
                }
            });
        }

        setupCompatibilityBridge() {
            // Backward compatibility untuk script lama
            if (!window.AudioSystem) {
                window.AudioSystem = {};
            }
            
            window.AudioSystem.initializeVoiceSearch = (searchRoute) => {
                console.log('🌉 Using compatibility bridge for voice search');
                this.searchUrl = searchRoute || this.searchUrl;
                return this;
            };
            
            if (!window.voiceCommand) {
                window.voiceCommand = {
                    init: () => {
                        console.log('🌉 Using compatibility bridge for voice command');
                        return this;
                    }
                };
            }

            // Global functions untuk manual control
            window.openVoiceSearchModal = () => this.toggleVoiceSearch();
            window.closeVoiceSearchModal = () => this.closeModal();
        }

        // Force stop method untuk coordination
        forceStop() {
            console.log('🛑 Force stopping voice search');
            this.stopVoiceSearch();
            this.stopWakeWordListening();
            this.closeModal();
        }

        cleanup() {
            this.forceStop();
            
            // Release recognition access
            if (window.AudioStatistik.VoiceCoordinator) {
                window.AudioStatistik.VoiceCoordinator.releaseRecognition(this.name);
            }
            
            this.isInitialized = false;
        }
    }

    // Initialize when DOM is ready
    function initVoiceSearch() {
        const voiceSearch = new VoiceSearch();
        
        // Store in namespace
        window.AudioStatistik.Voice.Search = voiceSearch;
        
        // Wait for page to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => voiceSearch.init());
        } else {
            // DOM already loaded, init with delay to ensure modal exists
            setTimeout(() => voiceSearch.init(), 500);
        }
    }

    // Initialize
    initVoiceSearch();

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        if (window.AudioStatistik.Voice.Search) {
            window.AudioStatistik.Voice.Search.cleanup();
        }
    });

    console.log('✅ Voice Search script loaded with coordination');

})();