<?php

namespace Database\Seeders;

use App\Models\AudioSetting;
use Illuminate\Database\Seeder;

class AudioSettingSeeder extends Seeder
{
    public function run(): void
    {
        AudioSetting::create([
            'voice_model' => 'default',
            'speech_rate' => 1.0,
            'audio_quality' => 128,
            'tts_config' => [
                'voice' => 'female_warm',
                'language' => 'id-ID',
                'pitch' => 0,
                'volume' => 0.8,
            ],
            'auto_play' => false,
        ]);
    }
}
